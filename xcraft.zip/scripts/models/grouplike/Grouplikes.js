'use strict';

/*
`Grouplikes` manages operations for a set of grouplike structures.
Each operation follows from the properties of a group.

Operations here are unambiguously defined by the structure. 
Unsupported operations are represented by returning the original expression 
(if the operation is unary) or null (if the operation is binary).
Return types are deeply immutable expressions. 
All functions are pure. 
*/
const Grouplikes = (grouplike_expressions_for_tag) => {

    const types = Object.freeze(Object.keys(grouplike_expressions_for_tag));

    const constant = value => new Expression('constant', Number(value));
    const variable = name => new Expression('variable', String(name));

    const add = grouplike_expressions_for_tag['add'].create;
    const mul = grouplike_expressions_for_tag['mul'].create;
    const pow = (base, exponent) => grouplike_expressions_for_tag['pow'].create([base, exponent]);
    const log = (base, result) => grouplike_expressions_for_tag['log'].create([base, result]);
    const root = (exponent, result) => grouplike_expressions_for_tag['root'].create([exponent, result]);
    const harmonic = contents => grouplike_expressions_for_tag['harmonic'].create(contents);

    // provided only as a convenience
    const div = (numerator, denominator) => mul([numerator, pow(denominator, constant(-1))]);

    const whole_threshold = 1e-10;

    function _is_whole(value) {
        return Math.abs(value - Math.round(value)) <= whole_threshold;
    }

    function _is_reciprocal(expression) {
        return expression.type === 'pow' &&
            expression.contents[1].type === 'constant' &&
            expression.contents[1].contents === -1;
    }

    function _contains_reciprocal(expression) {
        if (_is_reciprocal(expression)) return true;
        return Array.isArray(expression.contents) &&
            expression.contents.some(_contains_reciprocal);
    }

    /*
    Constant arithmetic may collapse to a Number unless doing so would turn an
    exact reciprocal expression into a non-integral decimal approximation.
    */
    function _constant_result(expression) {
        const value = evaluate(expression, {});
        if (!Number.isFinite(value)) return null;
        if (_contains_reciprocal(expression) && !_is_whole(value)) return null;
        return ExpressionCaveats.inherit(
            constant(_is_whole(value)? Math.round(value) : value),
            expression
        );
    }

    function simplify(expression) {
        const structure = grouplike_expressions_for_tag[expression.type];
        if (structure == null) return expression;
        const simplified = structure.simplify(expression, simplify, evaluate, _constant_result);
        return simplified === expression? expression : ExpressionCaveats.inherit(simplified, expression);
    }

    function append(type, left, right) {
        const structure = grouplike_expressions_for_tag[type];
        if (structure == null) return left;
        const appended = structure.append(left, right);
        return appended == null? null : ExpressionCaveats.inherit(appended, left, right);
    }

    function combine(type, left, right) {
        const structure = grouplike_expressions_for_tag[type];
        if (structure == null) return null;

        const combined = structure.combine(left, right);
        if (combined != null) return ExpressionCaveats.inherit(combined, left, right);

        return _constant_result(
            new Expression(type, Object.freeze([left, right]))
        );
    }

    function commute(expression, index1, index2) {
        const structure = grouplike_expressions_for_tag[expression.type];
        if (structure == null) return expression;
        const commuted = structure.commute(expression, index1, index2);
        return commuted === expression? expression : ExpressionCaveats.inherit(commuted, expression);
    }

    function cancel(expression, index) {
        const structure = grouplike_expressions_for_tag[expression.type];
        if (structure == null) return expression;
        const cancelled = structure.cancel(expression, index);
        return cancelled === expression? expression : ExpressionCaveats.inherit(cancelled, expression);
    }

    function collapse(expression, index1, index2, replacement) {
        const structure = grouplike_expressions_for_tag[expression.type];
        if (structure == null) return expression;
        const lo = Math.min(index1, index2);
        const hi = Math.max(index1, index2);
        const contents = expression.contents.slice();
        contents[lo] = replacement;
        contents.splice(hi, 1);
        const collapsed = structure.create(contents);
        return collapsed == null? null : ExpressionCaveats.inherit(collapsed, expression, replacement);
    }

    const evaluator = variables => expression => {
        const subevaluate = expression => evaluator(variables)(expression);
        const structure = grouplike_expressions_for_tag[expression.type];
        if (structure != null) { return structure.evaluator(subevaluate)(expression); }
        switch (expression.type) {
            case 'constant': return expression.contents;
            case 'variable': return variables[expression.contents];
            default: return NaN;
        }
    }

    const evaluate = (expression, variables) => evaluator(variables)(expression);

    return Object.freeze({
        types,
        constant,
        variable,
        add,
        mul,
        pow,
        log,
        root,
        harmonic,
        div,
        append,
        combine,
        commute,
        cancel,
        collapse,
        simplify,
        evaluate,
    });
};
